const V = "xyn-da3a929a73", DATA = "xyn-data-f70ca952";
const CORE = ["./", "index.html", "manifest.webmanifest", "icons/icon-192.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(V).then(c => c.addAll(CORE.map(u => new Request(u, {cache: "reload"})))).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V && k !== DATA && !k.startsWith("vp-")).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
const pageKey = u => { let p = u.pathname.replace(/index\.html$/, ""); if (!p.endsWith("/") && !/\.[a-z0-9]+$/i.test(p)) p += "/"; return new URL(p, u.origin).href; };
const save = (store, key, res) => { if (res && (res.ok || res.type === "opaque")) { const cp = res.clone(); caches.open(store).then(c => c.put(key, cp)).catch(() => {}); } return res; };
self.addEventListener("fetch", e => {
  const r = e.request; if (r.method !== "GET") return;
  const u = new URL(r.url), font = /fonts\.(googleapis|gstatic)\.com$/.test(u.hostname);
  if (u.origin !== location.origin && !font) return;
  if (u.pathname.includes("/voice/") && u.pathname.endsWith(".json")) { e.respondWith(fetch(r).then(res => save(V, r, res)).catch(() => caches.match(r))); return; }
  if (r.mode === "navigate" || u.pathname.endsWith("/") || u.pathname.endsWith(".html")) {
    const key = pageKey(u);
    e.respondWith(caches.open(V).then(async c => {
      const hit = await c.match(key) || await c.match(r, {ignoreSearch: true});
      const net = fetch(r).then(res => save(V, key, res));
      if (hit) { e.waitUntil(net.catch(() => {})); return hit; }
      return net.catch(() => caches.match(new URL("./", location.href).href));
    }));
    return;
  }
  const store = u.pathname.includes("/voice/") ? "vp-bins" : (font || /\/dict\//.test(u.pathname)) ? DATA : V;
  e.respondWith(caches.match(r).then(m => m || fetch(r).then(res => save(store, r, res))));
});
