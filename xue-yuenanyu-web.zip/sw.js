const PD = "xyn-data-pd", PDF = ["data-e0cfa9780a.js"];
const V = "xyn-03ef01ebf9", DATA = "xyn-data-83fec417";
const CORE = ["./", "index.html", "manifest.webmanifest", "icons/icon-192.png"];
self.addEventListener("install", e => { e.waitUntil(Promise.all([caches.open(V).then(c => c.addAll(CORE.map(u => new Request(u, {cache: "reload"})))), caches.open(PD).then(async c => { for (const f of PDF) { const u = new URL(f, self.registration.scope).href; if (!(await c.match(u))) await c.add(u); } })]).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V && k !== DATA && k !== PD && !k.startsWith("vp-")).map(k => caches.delete(k)))).then(() => caches.open(PD)).then(c => c.keys().then(ks => Promise.all(ks.filter(q => !PDF.some(f => q.url.endsWith("/" + f))).map(q => c.delete(q))))).then(() => self.clients.claim())); });
const pageKey = u => { let p = u.pathname.replace(/index\.html$/, ""); if (!p.endsWith("/") && !/\.[a-z0-9]+$/i.test(p)) p += "/"; return new URL(p, u.origin).href; };
const save = (store, key, res) => { if (res && (res.ok || res.type === "opaque")) { const cp = res.clone(); caches.open(store).then(c => c.put(key, cp)).catch(() => {}); } return res; };
self.addEventListener("fetch", e => {
  const r = e.request; if (r.method !== "GET") return;
  const u = new URL(r.url), font = /fonts\.(googleapis|gstatic)\.com$/.test(u.hostname);
  if (u.origin !== location.origin && !font) return;
  if (u.pathname.endsWith("version.json")) return;
  if (u.pathname.includes("/voice/") && u.pathname.endsWith(".json")) { e.respondWith(fetch(r).then(res => save(V, r, res)).catch(() => caches.match(r))); return; }
  if (r.mode === "navigate" || u.pathname.endsWith("/") || u.pathname.endsWith(".html")) {  // trang: lấy bản MỚI trên mạng trước (chờ tối đa 4 giây), mất mạng/chậm thì dùng bản đã lưu
    const key = pageKey(u);
    e.respondWith((async () => {
      const c = await caches.open(V);
      const net = fetch(u.href, {cache: "no-cache", credentials: "same-origin"}).then(res => { if (res && res.ok) c.put(key, res.clone()).catch(() => {}); return res; });
      try {
        const res = await Promise.race([net, new Promise((_, rej) => setTimeout(() => rej(0), 6000))]);
        if (res && res.ok) return res;
      } catch(_) {}
      e.waitUntil(net.catch(() => {}));
      return (await c.match(key)) || (await c.match(r, {ignoreSearch: true})) || (await caches.match(key)) || (await caches.match(new URL("./", location.href).href)) || net;
    })());
    return;
  }
  if (/\/data-[0-9a-f]{10}\.js$/.test(u.pathname)) { e.respondWith(caches.open(PD).then(c => c.match(r).then(h => h || fetch(r).then(res => { if (res.ok) c.put(r, res.clone()); return res; })))); return; }
  const store = u.pathname.includes("/voice/") ? "vp-bins" : (font || /\/dict\//.test(u.pathname)) ? DATA : V;
  e.respondWith(caches.match(r).then(m => m || fetch(r).then(res => save(store, r, res))));
});

/* study reminder: periodic background sync (installed web app, Chrome/Android) */
const rmDay = (d = new Date()) => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
async function rmCheck(){
  const c = await caches.open("vp-rm"), keys = await c.keys(), now = new Date(), day = rmDay(now);
  for (const k of keys) {
    const r = await c.match(k); if (!r) continue;
    let s; try { s = await r.json(); } catch(_) { continue; }
    if (!s.on) continue;
    const [h, m] = String(s.t || "20:00").split(":").map(Number);
    if (now.getHours() * 60 + now.getMinutes() < h * 60 + m) continue;
    if (s.last === day || s.noti === day) continue;
    s.noti = day; await c.put(k, new Response(JSON.stringify(s), {headers: {"Content-Type": "application/json"}}));
    await self.registration.showNotification(s.title, {body: s.body, tag: "study-remind-" + k.url, data: s.url, icon: s.icon ? new URL(s.icon, s.url).href : undefined});
  }
}
self.addEventListener("periodicsync", e => { if (e.tag === "study-remind") e.waitUntil(rmCheck().catch(() => {})); });
self.addEventListener("notificationclick", e => {
  e.notification.close();
  const url = e.notification.data || self.registration.scope;
  e.waitUntil(clients.matchAll({type: "window", includeUncontrolled: true}).then(L => { const w = L.find(c => c.url.startsWith(url)); return w ? w.focus() : clients.openWindow(url); }));
});
