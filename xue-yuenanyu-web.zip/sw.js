const V = "xyn-a871360be3", DATA = "xyn-data-83fec417";
const CORE = ["./", "index.html", "manifest.webmanifest", "icons/icon-192.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(V).then(c => c.addAll(CORE.map(u => new Request(u, {cache: "reload"})))).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V && k !== DATA && !k.startsWith("vp-")).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
const pageKey = u => { let p = u.pathname.replace(/index\.html$/, ""); if (!p.endsWith("/") && !/\.[a-z0-9]+$/i.test(p)) p += "/"; return new URL(p, u.origin).href; };
const save = (store, key, res) => { if (res && (res.ok || res.type === "opaque")) { const cp = res.clone(); caches.open(store).then(c => c.put(key, cp)).catch(() => {}); } return res; };
self.addEventListener("fetch", e => {
  const r = e.request; if (r.method !== "GET") return;
  const u = new URL(r.url), font = /fonts\.(googleapis|gstatic)\.com$/.test(u.hostname);
  if (u.origin !== location.origin && !font) return;
  if (u.pathname.includes("/voice/") && u.pathname.endsWith(".json")) { e.respondWith(fetch(r).then(res => save(V, r, res)).catch(() => caches.match(r))); return; }
  if (r.mode === "navigate" || u.pathname.endsWith("/") || u.pathname.endsWith(".html")) {  // trang: lấy bản MỚI trên mạng trước (chờ tối đa 4 giây), mất mạng/chậm thì dùng bản đã lưu
    const key = pageKey(u);
    e.respondWith((async () => {
      const c = await caches.open(V);
      const net = fetch(u.href, {cache: "no-store", credentials: "same-origin"}).then(res => { if (res && res.ok) c.put(key, res.clone()).catch(() => {}); return res; });
      try {
        const res = await Promise.race([net, new Promise((_, rej) => setTimeout(() => rej(0), 4000))]);
        if (res && res.ok) return res;
      } catch(_) {}
      e.waitUntil(net.catch(() => {}));
      return (await c.match(key)) || (await c.match(r, {ignoreSearch: true})) || (await caches.match(key)) || (await caches.match(new URL("./", location.href).href)) || net;
    })());
    return;
  }
  const store = u.pathname.includes("/voice/") ? "vp-bins" : (font || /\/dict\//.test(u.pathname)) ? DATA : V;
  e.respondWith(caches.match(r).then(m => m || fetch(r).then(res => save(store, r, res))));
});
